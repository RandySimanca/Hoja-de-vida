

<template>
  <RouterView />
</template>

<script setup>
// No importa qué vista sea, se renderiza dinámicamente desde el router
</script>

<style>
/* Estilos globales opcionales */
</style>

