<script setup>

import Login from './Login.vue';

</script>

<template>
  
  <h2>Home Page</h2>
  <login />
</template>

<style></style>
