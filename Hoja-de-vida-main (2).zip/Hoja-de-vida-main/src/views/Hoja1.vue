<!-- src/views/Hoja1.vue -->
<template>
  <div class="section">
    <form @submit.prevent="enviarFormulario">
      <!-- Sección del encabezado -->
      <div>
        <HeaderComponent />
      </div>

      <!-- Sección de datos cargados -->
      <div v-if="hojaStore.cargado">
        <DatosPerComponent :datos="hojaStore.datosPersonales || {}" />
        <FormacionAcadComponent :formacion="hojaStore.formacionAcademica || {}" />
           </div>
     
    </form>
  </div>

  <div>
    <FooterComponent />
  </div>
</template>

<script setup>
/** ─────── 🔧 Imports ─────── **/
import { onMounted, ref } from "vue";
import { useHojaVidaStore } from "../stores/hojaVida";
import { useDatosStore } from "../stores/datos";
import { useUsuarioStore } from "../stores/usuarios";
import api from "../api/axios.js";

/** ─────── 🧠 Componentes ─────── **/
import HeaderComponent from "../components/HeaderComponent.vue";
import DatosPerComponent from "../components/DatosPerComponent.vue";
import FormacionAcadComponent from "../components/FormacionAcadComponent.vue";
import FooterComponent from "../components/FooterComponent.vue";

/** ─────── 🗂️ Instancias de stores ─────── **/
const hojaStore = useHojaVidaStore();
const datosStore = useDatosStore();
const usuarioStore = useUsuarioStore();

/** ─────── 🔐 Cargar datos si hay token ─────── **/
const token = localStorage.getItem("token");

onMounted(() => {
  if (!token) {
    console.error("❌ Token no encontrado. Redirigiendo o mostrando fallback...");
    // Aquí podrías redirigir al login si deseas
  } else {
    hojaStore.cargarHojaDeVida(); // ✅ Acción correcta del store
    console.log("✅ Token válido:", token);
  }
});

/** ─────── 📤 Envío de formulario (solo si deseas guardar) ─────── **/
const safeValue = (val) => (val !== undefined ? val : ""); // Protección básica

const enviarFormulario = async () => {
  const datosPersonales = {
    apellido1: safeValue(apellido1?.value),
    apellido2: safeValue(apellido2?.value),
    nombres: safeValue(nombres?.value),
    tipoDocumento: cedula?.value
      ? "C.C"
      : cedulExt?.value
      ? "C.E"
      : pasaporte?.value
      ? "PAS"
      : "",
    sexo: sexoF?.value ? "F" : sexoM?.value ? "M" : "",
    nacionalidad: nacionalidad?.value
      ? "Colombiana"
      : nacExt?.value
      ? "Extranjera"
      : "",
    pais: safeValue(pais?.value),
    libretaMilitar: safeValue(libretaMilitar?.value),
    numeroLibreta: safeValue(numeroLibreta?.value),
    dm: safeValue(dm?.value),
    fechaNacimiento: {
      dia: safeValue(diaNac?.value),
      mes: safeValue(mesNac?.value),
      ano: safeValue(anoNac?.value),
    },
    lugarNacimiento: {
      pais: safeValue(paisNac?.value),
      depto: safeValue(deptoNac?.value),
      municipio: safeValue(municipioNac?.value),
    },
    direccion: {
      pais: safeValue(paisCorr?.value),
      depto: safeValue(deptoCorr?.value),
      municipio: safeValue(municipioCorr?.value),
      direccion: safeValue(direccionCorr?.value),
      telefono: safeValue(telefono?.value),
      email: safeValue(email?.value),
    },
    idiomas: [
      {
        idioma: safeValue(idioma1?.value),
        habla: safeValue(habla1?.value),
        lee: safeValue(lee1?.value),
        escribe: safeValue(escribe1?.value),
      },
      {
        idioma: safeValue(idioma2?.value),
        habla: safeValue(habla2?.value),
        lee: safeValue(lee2?.value),
        escribe: safeValue(escribe2?.value),
      },
    ],
    formacionAcademica: [
      {
        modalidad: safeValue(modalidad1?.value),
        semestres: safeValue(semestres1?.value),
        graduado: safeValue(graduado1?.value),
        titulo: safeValue(titulo1?.value),
        mes: safeValue(mes1?.value),
        ano: safeValue(ano1?.value),
        tarjeta: safeValue(tarjeta1?.value),
      },
      {
        modalidad: safeValue(modalidad2?.value),
        semestres: safeValue(semestres2?.value),
        graduado: safeValue(graduado2?.value),
        titulo: safeValue(titulo2?.value),
        mes: safeValue(mes2?.value),
        ano: safeValue(ano2?.value),
        tarjeta: safeValue(tarjeta2?.value),
      },
      {
        modalidad: safeValue(modalidad3?.value),
        semestres: safeValue(semestres3?.value),
        graduado: safeValue(graduado3?.value),
        titulo: safeValue(titulo3?.value),
        mes: safeValue(mes3?.value),
        ano: safeValue(ano3?.value),
        tarjeta: safeValue(tarjeta3?.value),
      },
    ],
  };

  try {
    const respuesta = await api.post("/datos-personales", datosPersonales, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    console.log("✅ Datos enviados con éxito:", respuesta.data);
  } catch (error) {
    console.error("❌ Error al enviar datos:", error.response?.data || error.message);
  }
};
</script>

<style scoped>
.section {
  padding: 2rem;
}
</style>


<style>
.boton-guardar {
  background-color: #3498db;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s ease;
}

.boton-guardar:hover {
  background-color: #2980b9;
}

.h1 {
  font-size: 20px;
  font-weight: bold;
  text-align: center;
  margin-bottom: 32px;
  color: #ffffff;
  letter-spacing: 1px;
}
.main-content {
  flex-grow: 1;
  overflow-y: auto;
}

.main-content {
  flex-grow: 1;
  padding: 24px;
  height: 100%;
  overflow-y: auto;
}

.header {
  background-color: #24292e;
  color: #fff;
  padding: 16px;
  margin-bottom: 24px;
  border-radius: 12px;
  text-align: center;
}

.h1 {
  color: #f10c0c;
  text-align: center;
  margin-bottom: 24px;
}

.boton-cerrar {
  background-color: #ef4444;
  color: white;
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  font-weight: bold;
  cursor: pointer;
  transition: background 0.3s ease;
}

.boton-cerrar:hover {
  background-color: #dc2626;
}

.saludo {
  font-family: "Poppins", sans-serif;
  font-size: 1.1rem;
  color: #2c3e50;
  padding: 0.75rem 1rem;
  background-color: #f8f9fa;
  border-left: 4px solid #34495e;
  border-radius: 6px;
  box-shadow: 0 0 4px rgba(0, 0, 0, 0.05);
}

.saludo strong {
  color: #1a1a1a;
  font-weight: 600;
}

.saludo {
  text-align: center;
  margin-bottom: 24px;
}

.saludo {
  display: block;
  margin-bottom: 24px;
}

.layout {
  display: flex;
  height: 100vh;
  overflow: hidden;
}

.sidebar {
  width: 240px;
  flex-shrink: 0;
}

.sidebar-menu {
  list-style: none;
  padding: 0;
  margin: 0;
}

.sidebar {
  width: 240px;
  background: linear-gradient(135deg, #1d1f27, #2c2f36);
  color: #f1f1f1;
  padding: 20px;
  height: 100%;
  box-shadow: 2px 0 8px rgba(0, 0, 0, 0.3);
  font-family: "Segoe UI", sans-serif;
}

.sidebar-menu li {
  margin-bottom: 16px;
}

.sidebar-menu a {
  display: block;
  padding: 12px 16px;
  color: #e0e0e0;
  background-color: transparent;
  border-radius: 8px;
  text-decoration: none;
  font-weight: 500;
  transition: all 0.3s ease;
}

.sidebar-menu a:hover,
.sidebar-menu a.router-link-exact-active {
  background-color: #00d8ff22;
  color: #00d8ff;
  font-weight: 600;
  border-left: 4px solid #00d8ff;
}

.sidebar {
  width: 220px;
  background-color: #1d2024;
  color: white;
  padding: 20px;
  height: 100%;
}
.sidebar-menu {
  list-style: none;
  padding: 0;
  margin: 0;
}

.sidebar-menu li {
  margin-bottom: 16px;
}

.sidebar-menu a {
  color: white;
  text-decoration: none;
  font-weight: 500;
}

.sidebar-menu a:hover {
  color: #00d8ff;
}

.section-scrol {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  scroll-behavior: smooth;
}

.section {
  border: 2px solid rgb(0, 204, 255);
  padding: 10px;
  gap: 10px;
  display: block;
  border-radius: 18px;
  flex-direction: row;
  gap: 1px;
  align-items: flex-start;
  margin-top: 0;
  box-shadow: 6px 6px 0px rgba(0, 0, 0, 1);
}

.section-title {
  background-color: rgb(10, 10, 10);
  padding: 2px;
  margin-bottom: 5px;
  font-weight: bold;
  color: #ccc;
  max-width: fit-content;
  border-radius: 5px;
}
.section-number {
  display: inline-block;
  width: 20px;
  height: 20px;
  background-color: #b4b4b4;
  color: rgb(255, 255, 255);
  text-align: center;
  border-radius: 50%;
  margin-right: 10px;
}

.container1 {
  border: 5px solid rgb(0, 204, 255);
  border-radius: 18px;
}

.container {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1px;
  border: 2px solid rgb(0, 204, 255);
  border-radius: 18px;
  flex-direction: row;
  gap: 100px;
  box-shadow: 6px 6px 0px rgba(0, 0, 0, 1);
}

.image-column,
.form-group {
  flex: 1;
}

header {
  text-align: center;
}

.main-section {
  display: flex;
}

.header h2,
.header h3,
.header p {
  margin: 5px 0;
  color: #f8f6f6;
}

.header {
  margin-top: 0;
  align-items: center;
  background-color: #117de9;
  color: rgb(253, 252, 252);
  padding: 16px 32px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
  font-family: "Segoe UI", sans-serif;
  padding-top: 0;
  display: flex;
  justify-content: center;
  text-align: center;
}

form {
  margin-bottom: 40px;
}

.form-group label {
  display: block;
  font-weight: bold;
  margin-bottom: 3px;
  font-size: 11px;
}

.form-row {
  display: flex;
  flex-wrap: wrap;
  margin: 5px;
  outline: 2px solid #808080;
}
.form-group {
  margin-right: 5px;
  margin-bottom: 5px;
  flex: 1;
}

.form-control {
  width: 70%;
  padding: 4px;
  box-sizing: border-box;
  height: 28px;
}

.form-control1 {
  width: 100%;
  padding: 5px;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

.form-control2 {
  width: 50%;
  padding: 5px;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

.form-control3 {
  width: 30%;
  padding: 4px;
  box-sizing: border-box;
  height: 28px;
}

.checkbox-group {
  display: flex;
  align-items: left;
  margin-right: 5px;
}
.checkbox-group input {
  margin-left: 0px;
}
.imagen {
  width: 100px;
  height: 120px;
  border: 1px solid #ccc;
  display: block;
  margin: 0 auto;
  border-radius: 8px;
}

.table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 10px;
}
.table th,
.table td {
  border: 1px solid #ccc;
  padding: 1px;
  text-align: center;
  font-size: 12px;
}
.table th {
  background-color: #f0f0f0;
}

.compacto h3,
.compacto h2,
.compacto p {
  margin-top: 0;
  margin-bottom: 4px;
  text-align: center;
}

.col-2 {
  flex: 10 0 10%;
}
.col-3 {
  flex: 0 0 31%;
}
.col-4 {
  flex: 0 0 23%;
}

.p {
  font-size: 11px;
}
</style>
