<template>
  <RouterView />
</template>

<script setup>
// No necesita lógica
</script>

<style scoped>
/* Puedes dejarlo vacío o agregar estilos globales si lo deseas */
</style>
