<template>
    <div class="">
        <div class="compacto">
          <h3>FORMATO ÚNICO</h3>
          <h2>HOJA DE VIDA</h2>
          <p>Persona Natural</p>
          <p>(Leyes 190 de 1995, 489 y 443 de 1998)</p>
        </div>
      </div>
</template>

<script>
export default {
    name: "Header2Component"
}

</script>

<style>

</style>