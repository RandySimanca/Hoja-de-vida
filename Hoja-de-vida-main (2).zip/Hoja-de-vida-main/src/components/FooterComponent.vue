<template>
  <footer class="site-footer">
    <div class="footer-content">
      <p>
        LÍNEA GRATUITA NACIONAL 01800917770 - PÁGINA WEB:
        www.funcionpublica.gov.co
      </p>
    </div>
  </footer>
</template>

<script>
export default {
  name: "FooterComponent",
};
</script>

<style scoped>
.site-footer {
  background-color: #eff2f5;
  color: rgb(14, 13, 13);
  padding: 20px;
  text-align: center;
  border-radius: 18px;
}

</style>
